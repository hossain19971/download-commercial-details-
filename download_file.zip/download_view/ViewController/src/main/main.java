package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import model.AppModuleImpl;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;

import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.jbo.ApplicationModule;

public class main {
    private static Object Udownload;
    private RichInputText udownload;

    public main() {
    }
    
    public ApplicationModule getAppM() {
        DCBindingContainer bindingContainer =
            (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
        //BindingContext bindingContext = BindingContext.getCurrent();
        DCDataControl dc =
            bindingContainer.findDataControl("AppModuleDataControl"); // Name of application module in datacontrolBinding.cpx
        AppModuleImpl appM = (AppModuleImpl)dc.getDataProvider();
        return appM;
        }
    
    AppModuleImpl appM = (AppModuleImpl)this.getAppM();

    public void custom_download(FacesContext facesContext, OutputStream outputStream)throws IOException  {
        // Add event code here...
        
   
            // Add event code here...
            
                    // Add event code here...
                    //Read file from particular path, path bind is binding of table field that contains path
                    File filed = new File(udownload.getValue().toString());
                    FileInputStream fis;
                    System.out.println("file path is ****************" + filed);
                    byte[] b;
                    try {
                        fis = new FileInputStream(filed);
                        System.out.println("case 2 fis variable done");
                        int n;
                        while ((n = fis.available()) > 0) {
                            b = new byte[n];
                            int result = fis.read(b);
                            outputStream.write(b, 0, b.length);
                            if (result == -1)
                                System.out.println("case 3 while in if");
                            break;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        FacesMessage msg =
                            new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(),
                                             "");
                        FacesContext.getCurrentInstance().addMessage(null, msg);
                    }
                    outputStream.flush();
        
        }


    public void setUdownload(RichInputText udownload) {
        this.udownload = udownload;
    }

    public RichInputText getUdownload() {
        return udownload;
    }
}
